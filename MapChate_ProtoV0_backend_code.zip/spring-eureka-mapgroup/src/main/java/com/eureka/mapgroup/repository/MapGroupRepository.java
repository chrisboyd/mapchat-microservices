package com.eureka.mapgroup.repository;

import com.eureka.mapgroup.entities.MapGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MapGroupRepository extends JpaRepository<MapGroup,Integer>{

}
