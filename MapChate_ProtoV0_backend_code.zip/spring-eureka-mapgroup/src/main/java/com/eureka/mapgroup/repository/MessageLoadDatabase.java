package com.eureka.mapgroup.repository;

public class MessageLoadDatabase {

}
