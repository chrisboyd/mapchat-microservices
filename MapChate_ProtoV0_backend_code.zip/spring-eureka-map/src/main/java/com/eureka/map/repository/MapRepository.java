package com.eureka.map.repository;

import com.eureka.map.entities.Map;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MapRepository extends JpaRepository<Map,Integer>{

}
