public class Tester {
	
	
	public static void main(String[] args) {
		System.out.println("Ip Counter: ");
		
		String ip = "1.2.3.4";
		log_file_checker check = new log_file_checker();
		System.out.println(check.ip_counter(100, 10000, ip));
	}

}
