import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class log_file_checker {
	
	private String zeroTo255 = "(\\d{1,2}|(0|1)\\" + "d{2}|2[0-4]\\d|25[0-5])";
	private String regex = zeroTo255 + "\\." + zeroTo255 + "\\." + zeroTo255 + "\\." + zeroTo255;
	private Pattern p = Pattern.compile(regex); 
	
	Calendar cal = Calendar.getInstance();
	long startTime = cal.getTimeInMillis();
	long currentTime = startTime;
	
	public log_file_checker () {
		
	}

	public int ip_counter (int requests, int period, String give_ip) {
		int counter = 0;
		
		BufferedReader reader;
		
		try {
			reader = new BufferedReader(new FileReader("C:\\Users\\raza9\\Desktop\\random.txt"));
			String line = reader.readLine();

			while (line != null && currentTime < (startTime + period)) {
			    
				Matcher matcher = p.matcher(line); 
			    
			    if (matcher.find() && matcher.group(0).equals(give_ip)) {
			    	System.out.println(matcher.group(0));
			    	counter++;
			    }
				line = reader.readLine();
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return counter;
	}
}
