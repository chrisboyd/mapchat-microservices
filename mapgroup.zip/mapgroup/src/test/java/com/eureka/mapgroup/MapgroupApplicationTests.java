package com.eureka.mapgroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapgroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
